const mysql = require("mysql2");

// UPDATE these to your mysql credentials
const pool = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "Swarrr@55555",
  database: "discord_logger"
});

module.exports = pool.promise();
