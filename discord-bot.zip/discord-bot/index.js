const { Client, GatewayIntentBits } = require('discord.js');
const express = require('express');
const db = require('./db');   // <-- MySQL connection
const app = express();

// For saving messages temporarily (optional)
let chatDB = [];

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

// Debug: Check bot login
client.on("ready", () => {
  console.log(`Bot logged in as ${client.user.tag}`);
});

// Set your target channel name
const TARGET_CHANNEL = "general";

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  if (message.channel.name === TARGET_CHANNEL) {
    const log = {
      username: message.author.username,
      text: message.content,
      timestamp: message.createdAt,
      channel: TARGET_CHANNEL
    };

    chatDB.push(log);
    console.log("Saving to MySQL:", log);

    try {
      await db.query(
        "INSERT INTO messages (username, text, timestamp, channel) VALUES (?, ?, ?, ?)",
        [log.username, log.text, log.timestamp, log.channel]
      );
      console.log("Saved to MySQL ✔️");
    } catch (err) {
      console.error("MySQL Error:", err);
    }
  }
});

// IMPORTANT: login bot
client.login("MTQ0MjQyOTgxNjY5ODgzMDk5OA.GOwVYM.ICCN0VWAMdTNdxcBSd-ZFqRu8zpCAGouSnoudQ");

// API route
app.get("/messages", (req, res) => {
  res.json(chatDB);
});

app.listen(3000, () => console.log("Logger API running on port 3000"));
